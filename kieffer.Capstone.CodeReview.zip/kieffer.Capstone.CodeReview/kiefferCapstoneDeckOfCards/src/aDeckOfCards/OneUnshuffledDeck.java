package aDeckOfCards;

public class OneUnshuffledDeck 
{
	public OneUnshuffledDeck()
	{
		String[]theDeck = makeADeckArray();
		theDeck = initializeTheDeck(theDeck);
		theDeck = addTheCardNumbersToTheDeckString(theDeck);
		theDeck = addTheFaceNameToDeckString(theDeck);
		theDeck = addAceToTheDeckString(theDeck);
		theDeck = addSuitesToTheDeckString(theDeck);
		theDeck = shuffleTheDeck(theDeck);
		
		returnTheDeck(theDeck);
	}
	
	public String[] makeADeckArray()
	{
		//an array of 52 strings 
		
		String[] theDeck = new String[52];
		
		return theDeck;
	}
	
	public String[] initializeTheDeck(String[]theDeck)
	{
		//assign numeric(toSttring()) value to each card in the deck
		//card numbers are from 1 to 52
		
		for(int n = 0; n < theDeck.length; n++)
		{
			theDeck[n] = String.valueOf(n + 1); 
		}
		
		return theDeck;
	}
	
	public String[] addTheCardNumbersToTheDeckString(String[] theDeck)
	{
		//append the card number to each card that will end up as a number 
		
		int theCard;
		
		for(int n = 0; n < theDeck.length; n++)
		{
			theCard = Integer.parseInt(theDeck[n]) % 13;
			
			theDeck[n] = String.valueOf(theCard);
		}
		
		return theDeck;
	}
	
	public String[] addTheFaceNameToDeckString(String[]theDeck)
	{
		//append face names to each card
		
		for(int n = 0; n < theDeck.length; n++)
		{ 
			if(theDeck[n].equals("11"))
			{ 
				theDeck[n] = "jack";
			}
			else if(theDeck[n].equals("12"))
			{ 
				theDeck[n] = "queen";
			}
			else if(theDeck[n].equals("0"))
			{ 
				theDeck[n] = "king";
			}
		}
		
		return theDeck;
	}
	
	public String[] addAceToTheDeckString(String[] theDeck)
	{
		//append 'ace' to each card that will end up as an ace
		
		for(int n = 0; n < theDeck.length; n++)
		{ 
			if(theDeck[n].equals("1"))
			{ 
				theDeck[n] = "ace"; 
			}
		}
		
		return theDeck;
	}
	
	public String[] addSuitesToTheDeckString(String[] theDeck)
	{
		//append suite to each card number
		//1-13 are clubs
		//14-26 are diamonds 
		//27-39 are hearts
		//40-52 are spades
		
		for(int n = 0; n < theDeck.length; n++)
		{ 
			if(n / 13 == 0)
			{ 
				theDeck[n]+= " clubs";
			}
			else if(n / 13 == 1)
			{ 
				theDeck[n]+= " diamonds";
			}
			else if(n / 13 == 2)
			{ 
				theDeck[n]+= " hearts";
			}
			else if(n / 13 == 3)
			{ 
				theDeck[n]+= " spades";
			}
		}
		
		return theDeck;
	}
	
	public String[] returnTheDeck(String[] theDeck)
	{
		for(int n = 0; n < theDeck.length; n++)
		{ 
			System.out.print(theDeck[n] + " ");
			
			if(n % 13 == 0)
				System.out.println();
		}
		
		return theDeck;
	}
	
	public String[] shuffleTheDeck(String[] theDeck)
	{
		String[] shuffleTheCards = new String[theDeck.length];
		
		for(int n = 0; n < theDeck.length; n++)
		{
			int newCardOrder = (int) (Math.random() * theDeck.length);
			
			while(theDeck[newCardOrder] == "-1")
			{
				newCardOrder++; 
				
				if(newCardOrder == theDeck.length)
					newCardOrder = 0;
			}
			
			shuffleTheCards[n] = theDeck[newCardOrder];
			
			theDeck[newCardOrder] = "-1";
			
			//Felipe helped me fix what I was doing wrong with this part
		}
		
		return shuffleTheCards;
	}
}
