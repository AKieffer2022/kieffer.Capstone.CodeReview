package deckOfCards;

public class OneUnshuffledDeck 
{
	public OneUnshuffledDeck()
	{
		
	}
	
	public String[] makeADeckArray()
	{
		//an array of 52 strings 
	}
	
	public String[] initializeTheDeck(String[]theDeck)
	{
		//assign numeric(toSttring()) value to each card in the deck
		//card numbers are from 1 to 52
	}
	
	public String[] addSuitesToTheDeckString(String[] theDeck)
	{
		//append suite to each card number
		//1-13 are clubs
		//14-26 are diamonds 
		//27-39 are hearts
		//40-52 are spades
	}
	
	public String[] addTheCardNumbersToTheDeckString(String[] theDeck)
	{
		//append the card number to each card that will end up as a number 
	}
	
	public String[] addTheFaceNameToDeckString(String[]theDeck)
	{
		//append face names to each card
	}
	
	public String[] addAceToTheDeckString(String[] theDeck)
	{
		//append 'ace' to each card that will end up as an ace
	}
	
	public String[] returnTheDeck(String[] theDeck)
	{
		
	}
}
